import mysql.connector
from mysql.connector import Error
from datetime import datetime

# ==============================
#  Clases de dominio
# ==============================

class Persona:
    def __init__(self, nombre, correo, direccion, telefono):
        self.nombre = nombre
        self.correo = correo
        self.direccion = direccion
        self.telefono = telefono

    def mostrar_info(self):
        print(
            f"Nombre: {self.nombre} | Correo: {self.correo} | "
            f"Dirección: {self.direccion} | Teléfono: {self.telefono}"
        )

class Cliente(Persona):
    def __init__(self, nombre, correo, direccion, telefono, rfc):
        super().__init__(nombre, correo, direccion, telefono)
        self.rfc = rfc

    def mostrar_info(self):
        super().mostrar_info()
        print(f"RFC: {self.rfc}")


class Empleado(Persona):
    def __init__(self, nombre, correo, direccion, telefono,
                 clave_emp, departamento, usuario, contrasena):
        super().__init__(nombre, correo, direccion, telefono)
        self.clave_emp = clave_emp
        self.departamento = departamento
        self.usuario = usuario
        self.contrasena = contrasena

    def mostrar_info(self):
        super().mostrar_info()
        print(
            f"Clave empleado: {self.clave_emp} | "
            f"Departamento: {self.departamento} | Usuario: {self.usuario}"
        )

class Producto:
    def __init__(self, codigo, nombre, categoria, precio):
        self.codigo = codigo
        self.nombre = nombre
        self.categoria = categoria
        self.precio = precio

    def mostrar_info(self):
        print(
            f"Código: {self.codigo} | Nombre: {self.nombre} | "
            f"Categoría: {self.categoria} | Precio: ${self.precio:.2f}"
        )


class InventarioProducto:
    def __init__(self, producto, cantidad):
        self.producto = producto
        self.cantidad = cantidad
        self.vendidos = 0

    def disponibles(self):
        return self.cantidad - self.vendidos

    def mostrar_estado(self):
        self.producto.mostrar_info()
        print(
            f"Cantidad en inventario: {self.cantidad} | "
            f"Vendidos: {self.vendidos} | Disponibles: {self.disponibles()}"
        )


class Venta:
    def __init__(self, folio, id_cliente, codigo_producto, fecha, cantidad, total):
        self.folio = folio
        self.id_cliente = id_cliente   # en nuestro caso se guarda el RFC
        self.codigo_producto = codigo_producto
        self.fecha = fecha
        self.cantidad = cantidad
        self.total = total

    def mostrar_info(self):
        print(
            f"Folio: {self.folio} | RFC cliente: {self.id_cliente} | "
            f"Código producto: {self.codigo_producto} | Fecha: {self.fecha} | "
            f"Cantidad: {self.cantidad} | Total: ${self.total:.2f}"
        )


# ==============================
#  Variables globales de sesión
# ==============================

sesion_activa = None
folio_actual = 1


# ==============================
#  Funciones de conexión a MySQL
# ==============================

def crear_conexion():
    """
    Crea y regresa una conexión a la base de datos MySQL.
    Ajusta usuario y contraseña según tu instalación.
    """
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",          # Cambia por tu usuario de MySQL
            password="Alvazer12&",  # Cambia por tu contraseña de MySQL
            database="ferreteria"
        )
        return conexion
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
        return None


def inicializar_bd():
    """
    Crea la base de datos y las tablas necesarias, si no existen.
    También crea un empleado administrador por defecto.
    """
    try:
        # Conexión sin especificar base de datos para poder crearla
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Alvazer12&"   # Debe coincidir con la contraseña anterior
        )
        cursor = conexion.cursor()

        # Crear base de datos si no existe
        cursor.execute("CREATE DATABASE IF NOT EXISTS ferreteria")
        cursor.execute("USE ferreteria")

        # Tabla clientes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clientes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100),
                correo VARCHAR(100),
                direccion VARCHAR(150),
                telefono VARCHAR(20),
                rfc VARCHAR(20) UNIQUE
            )
        """)

        # Tabla empleados
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS empleados (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100),
                correo VARCHAR(100),
                direccion VARCHAR(150),
                telefono VARCHAR(20),
                clave_emp VARCHAR(20) UNIQUE,
                departamento VARCHAR(50),
                usuario VARCHAR(50) UNIQUE,
                contrasena VARCHAR(50)
            )
        """)

        # Tabla productos
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS productos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                codigo VARCHAR(20) UNIQUE,
                nombre VARCHAR(100),
                categoria VARCHAR(50),
                precio FLOAT,
                stock INT
            )
        """)

        # Tabla ventas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ventas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                folio INT,
                rfc_cliente VARCHAR(20),
                codigo_producto VARCHAR(20),
                fecha DATETIME,
                cantidad INT,
                total FLOAT
            )
        """)

        # Crear empleado administrador por defecto si no existe
        cursor.execute(
            "SELECT COUNT(*) FROM empleados WHERE usuario = %s",
            ("admin",)
        )
        existe_admin = cursor.fetchone()[0]

        if existe_admin == 0:
            cursor.execute("""
                INSERT INTO empleados
                (nombre, correo, direccion, telefono,
                 clave_emp, departamento, usuario, contrasena)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            """, (
                "Administrador",
                "admin@ferreteria.com",
                "Sucursal central",
                "555-0000",
                "E001",
                "Administración",
                "admin",
                "1234"
            ))
            print(
                "Empleado administrador creado por defecto "
                "(usuario: admin, contraseña: 1234)."
            )

        conexion.commit()
        cursor.close()
        conexion.close()

    except Error as e:
        print(f"Error al inicializar la base de datos: {e}")


# ==============================
#  Funciones CRUD para clientes
# ==============================

def registrar_cliente_bd(cliente):
    conexion = crear_conexion()
    if not conexion:
        return
    try:
        cursor = conexion.cursor()
        sql = """
            INSERT INTO clientes (nombre, correo, direccion, telefono, rfc)
            VALUES (%s,%s,%s,%s,%s)
        """
        valores = (
            cliente.nombre,
            cliente.correo,
            cliente.direccion,
            cliente.telefono,
            cliente.rfc
        )
        cursor.execute(sql, valores)
        conexion.commit()
        print("Cliente registrado correctamente.")
    except Error as e:
        print(f"Error al registrar cliente: {e}")
    finally:
        conexion.close()


def buscar_cliente_por_rfc(rfc):
    conexion = crear_conexion()
    if not conexion:
        return None
    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT nombre, correo, direccion, telefono, rfc
            FROM clientes
            WHERE rfc = %s
        """, (rfc,))
        fila = cursor.fetchone()
        if fila:
            nombre, correo, direccion, telefono, rfc = fila
            return Cliente(nombre, correo, direccion, telefono, rfc)
        return None
    except Error as e:
        print(f"Error al buscar cliente: {e}")
        return None
    finally:
        conexion.close()


def obtener_todos_los_clientes():
    conexion = crear_conexion()
    if not conexion:
        return []
    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT nombre, correo, direccion, telefono, rfc
            FROM clientes
        """)
        filas = cursor.fetchall()
        clientes = []
        for fila in filas:
            nombre, correo, direccion, telefono, rfc = fila
            clientes.append(Cliente(nombre, correo, direccion, telefono, rfc))
        return clientes
    except Error as e:
        print(f"Error al obtener clientes: {e}")
        return []
    finally:
        conexion.close()


# ==============================
#  Funciones CRUD para productos
# ==============================

def registrar_producto_bd(producto, cantidad_inicial):
    conexion = crear_conexion()
    if not conexion:
        return
    try:
        cursor = conexion.cursor()
        sql = """
            INSERT INTO productos (codigo, nombre, categoria, precio, stock)
            VALUES (%s,%s,%s,%s,%s)
        """
        valores = (
            producto.codigo,
            producto.nombre,
            producto.categoria,
            producto.precio,
            cantidad_inicial
        )
        cursor.execute(sql, valores)
        conexion.commit()
        print("Producto registrado correctamente.")
    except Error as e:
        print(f"Error al registrar producto: {e}")
    finally:
        conexion.close()


def buscar_producto_bd(codigo):
    conexion = crear_conexion()
    if not conexion:
        return None
    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT codigo, nombre, categoria, precio, stock
            FROM productos
            WHERE codigo = %s
        """, (codigo,))
        fila = cursor.fetchone()
        if fila:
            codigo, nombre, categoria, precio, stock = fila
            producto = Producto(codigo, nombre, categoria, precio)
            return InventarioProducto(producto, stock)
        return None
    except Error as e:
        print(f"Error al buscar producto: {e}")
        return None
    finally:
        conexion.close()


def obtener_todos_los_productos():
    conexion = crear_conexion()
    if not conexion:
        return []
    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT codigo, nombre, categoria, precio, stock
            FROM productos
        """)
        filas = cursor.fetchall()
        inventario = []
        for fila in filas:
            codigo, nombre, categoria, precio, stock = fila
            producto = Producto(codigo, nombre, categoria, precio)
            inventario.append(InventarioProducto(producto, stock))
        return inventario
    except Error as e:
        print(f"Error al obtener productos: {e}")
        return []
    finally:
        conexion.close()


def actualizar_stock_producto(codigo, cantidad_a_restar):
    """
    Resta la cantidad indicada al stock del producto.
    Regresa True si se pudo actualizar, False en otro caso.
    """
    conexion = crear_conexion()
    if not conexion:
        return False
    try:
        cursor = conexion.cursor()
        cursor.execute(
            "SELECT stock FROM productos WHERE codigo = %s",
            (codigo,)
        )
        fila = cursor.fetchone()
        if not fila:
            print("Producto no encontrado en la base de datos.")
            return False

        stock_actual = fila[0]
        if stock_actual < cantidad_a_restar:
            print("No hay suficiente inventario disponible.")
            return False

        nuevo_stock = stock_actual - cantidad_a_restar
        cursor.execute(
            "UPDATE productos SET stock = %s WHERE codigo = %s",
            (nuevo_stock, codigo)
        )
        conexion.commit()
        return True
    except Error as e:
        print(f"Error al actualizar stock: {e}")
        return False
    finally:
        conexion.close()


# ==============================
#  Funciones CRUD para ventas
# ==============================

def registrar_venta_bd(venta):
    conexion = crear_conexion()
    if not conexion:
        return
    try:
        cursor = conexion.cursor()
        sql = """
            INSERT INTO ventas
            (folio, rfc_cliente, codigo_producto, fecha, cantidad, total)
            VALUES (%s,%s,%s,%s,%s,%s)
        """
        valores = (
            venta.folio,
            venta.id_cliente,
            venta.codigo_producto,
            venta.fecha,
            venta.cantidad,
            venta.total
        )
        cursor.execute(sql, valores)
        conexion.commit()
        print("Venta registrada correctamente.")
    except Error as e:
        print(f"Error al registrar venta: {e}")
    finally:
        conexion.close()


def obtener_historial_ventas():
    conexion = crear_conexion()
    if not conexion:
        return []
    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT folio, rfc_cliente, codigo_producto, fecha, cantidad, total
            FROM ventas
        """)
        filas = cursor.fetchall()
        ventas = []
        for fila in filas:
            folio, rfc_cliente, codigo_producto, fecha, cantidad, total = fila
            venta = Venta(folio, rfc_cliente, codigo_producto, fecha, cantidad, total)
            ventas.append(venta)
        return ventas
    except Error as e:
        print(f"Error al obtener historial de ventas: {e}")
        return []
    finally:
        conexion.close()


# ==============================
#  Manejo de sesión (login/logout)
# ==============================

def login():
    """
    Solicita usuario y contraseña y valida contra la tabla empleados.
    """
    global sesion_activa
    print("\n===== INICIO DE SESIÓN =====")
    usuario = input("Usuario: ")
    contrasena = input("Contraseña: ")

    conexion = crear_conexion()
    if not conexion:
        return False

    try:
        cursor = conexion.cursor()
        cursor.execute("""
            SELECT nombre, correo, direccion, telefono,
                   clave_emp, departamento, usuario, contrasena
            FROM empleados
            WHERE usuario = %s AND contrasena = %s
        """, (usuario, contrasena))
        fila = cursor.fetchone()

        if fila:
            nombre, correo, direccion, telefono, clave_emp, departamento, usuario_db, contrasena_db = fila
            sesion_activa = Empleado(
                nombre, correo, direccion, telefono,
                clave_emp, departamento, usuario_db, contrasena_db
            )
            print(
                f"\nBienvenido, {sesion_activa.nombre} "
                f"({sesion_activa.departamento}).\n"
            )
            return True
        else:
            print("Usuario o contraseña incorrectos.")
            return False
    except Error as e:
        print(f"Error al iniciar sesión: {e}")
        return False
    finally:
        conexion.close()


def logout():
    """
    Cierra la sesión actual.
    """
    global sesion_activa
    if sesion_activa:
        print(f"Cerrando sesión de {sesion_activa.nombre}...")
        sesion_activa = None
    else:
        print("No hay ninguna sesión activa.")


# ==============================
#  Menú principal del sistema
# ==============================

def mostrar_menu():
    print("=========== MENÚ PRINCIPAL ===========")
    print("1. Registrar producto")
    print("2. Mostrar inventario")
    print("3. Consultar producto por código")
    print("4. Registrar cliente")
    print("5. Consultar cliente por RFC")
    print("6. Mostrar todos los clientes")
    print("7. Registrar venta")
    print("8. Mostrar historial de ventas")
    print("9. Cerrar sesión")
    print("10. Salir")
    print("======================================")


def menu():
    global folio_actual

    # Exigir inicio de sesión antes de usar el sistema
    while not sesion_activa:
        if not login():
            opcion = input("¿Intentar de nuevo? (s/n): ").strip().lower()
            if opcion != "s":
                print("Saliendo del sistema...")
                return

    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            # Registrar producto
            try:
                codigo = input("Código del producto: ")
                nombre = input("Nombre del producto: ")
                categoria = input("Categoría: ")
                precio = float(input("Precio unitario: "))
                cantidad = int(input("Cantidad inicial en inventario: "))

                nuevo_producto = Producto(codigo, nombre, categoria, precio)
                registrar_producto_bd(nuevo_producto, cantidad)
            except ValueError:
                print("Error: precio y cantidad deben ser numéricos.")

        elif opcion == "2":
            # Mostrar inventario
            inventario_actual = obtener_todos_los_productos()
            if not inventario_actual:
                print("No hay productos registrados.")
            else:
                for item in inventario_actual:
                    item.mostrar_estado()

        elif opcion == "3":
            # Consultar producto por código
            codigo = input("Código del producto a consultar: ")
            item = buscar_producto_bd(codigo)
            if item:
                item.mostrar_estado()
            else:
                print("Producto no encontrado.")

        elif opcion == "4":
            # Registrar cliente
            nombre = input("Nombre del cliente: ")
            correo = input("Correo electrónico: ")
            direccion = input("Dirección: ")
            telefono = input("Teléfono: ")
            rfc = input("RFC: ")
            nuevo_cliente = Cliente(nombre, correo, direccion, telefono, rfc)
            registrar_cliente_bd(nuevo_cliente)

        elif opcion == "5":
            # Consultar cliente por RFC
            rfc = input("RFC del cliente a consultar: ")
            cliente = buscar_cliente_por_rfc(rfc)
            if cliente:
                cliente.mostrar_info()
            else:
                print("Cliente no encontrado.")

        elif opcion == "6":
            # Mostrar todos los clientes
            lista_clientes = obtener_todos_los_clientes()
            if not lista_clientes:
                print("No hay clientes registrados.")
            else:
                for cliente in lista_clientes:
                    cliente.mostrar_info()

        elif opcion == "7":
            # Registrar venta
            try:
                rfc_cliente = input("RFC del cliente: ")
                cliente = buscar_cliente_por_rfc(rfc_cliente)
                if not cliente:
                    print("Cliente no encontrado. Regístrelo primero.")
                    continue

                codigo_producto = input("Código del producto: ")
                item = buscar_producto_bd(codigo_producto)
                if not item:
                    print("Producto no encontrado.")
                    continue

                cantidad = int(input("Cantidad a vender: "))

                # Intentar actualizar stock
                if actualizar_stock_producto(codigo_producto, cantidad):
                    fecha = datetime.now()
                    total = item.producto.precio * cantidad
                    venta = Venta(
                        folio_actual,
                        rfc_cliente,
                        codigo_producto,
                        fecha,
                        cantidad,
                        total
                    )
                    registrar_venta_bd(venta)
                    folio_actual += 1
                else:
                    print("No se pudo completar la venta.")
            except ValueError:
                print("Error: la cantidad debe ser numérica.")

        elif opcion == "8":
            # Mostrar historial de ventas
            historial = obtener_historial_ventas()
            if not historial:
                print("No hay ventas registradas.")
            else:
                for venta in historial:
                    venta.mostrar_info()

        elif opcion == "9":
            # Cerrar sesión
            logout()
            # Si se cierra sesión, forzamos a iniciar nuevamente o salir
            while not sesion_activa:
                if not login():
                    op = input("¿Intentar de nuevo? (s/n): ").strip().lower()
                    if op != "s":
                        print("Saliendo del sistema...")
                        return

        elif opcion == "10":
            print("Gracias por usar el sistema. ¡Hasta pronto!")
            break

        else:
            print("Opción inválida. Intente de nuevo.")


if __name__ == "__main__":
    inicializar_bd()
    menu()